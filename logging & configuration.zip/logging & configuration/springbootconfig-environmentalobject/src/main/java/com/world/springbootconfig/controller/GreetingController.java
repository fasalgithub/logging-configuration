package com.world.springbootconfig.controller;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.world.springbootconfig.bean.DBRepository;

@RestController
public class GreetingController 
{
	//Spring expression Language
	
	@Value("${my.greetings}")
	private String greetingMessage;
	
	
	//U can look into appplication.properties
	@Value("${app.description}")
	private String myAppDescription;
	
	
	@Autowired
	//Environment variables
	private Environment env;
	
	@GetMapping("/")
	public String welcomeMessage() 
	{
		return myAppDescription;
	}
	
	@GetMapping("/active-profiles")
	public String[] getMyActiveProfile() 
	{
		return env.getActiveProfiles();
	}
	
	@GetMapping("/all-props")
	public String getMyAllProfile() 
	{
		return env.toString();
	}
	
	@GetMapping("/default-profiles")
	public String[] getMyDefaultProfile() 
	{
		
		return env.getDefaultProfiles();
	}
	
	
	
}

package com.world.springbootconfig.controller;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.world.springbootconfig.bean.DBRepository;

@RestController
public class GreetingController 
{
	//Spring expression Language
	
	@Value("${my.greetings}")
	private String greetingMessage;
	
	
	//U can look into appplication.properties
	@Value("${app.description}")
	private String myAppDescription;
	
	//static Message
	@Value("some static message")
	private String staticMessage;

	//default Message(if that property does not exist on property file we should get error)
	@Value("${my.greetings : default value}")
	private String defaultMessage;
	
	//Getting list of value Without splitted by Camma(,)
	@Value("${my.list}")
	private List<String> listOfTech;
	
	//Evaluated Spring Expresion Language -> Like Json Format
	@Value("#{${my.dbconnection}}")
	private Map<String, String> mydbconnection;
	
	//Creating Bean
	@Autowired
	private DBRepository repository;
	
	
	@GetMapping("/")
	public String welcomeMessage() 
	{
		return myAppDescription;
	}
	
	@GetMapping("/list")
	public List<String> getMyTechnology() 
	{
		return listOfTech;
	}
	
	@GetMapping("/map")
	public Map<String, String> getMyDbConnection() 
	{
		return mydbconnection;
	}
	
	@GetMapping("/repo")
	public DBRepository getMyDBRespo()
	{
		return repository;
	}
	
}
